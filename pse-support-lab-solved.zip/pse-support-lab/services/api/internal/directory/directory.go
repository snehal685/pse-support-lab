// Package directory checks Peppol participant registration through the ASP.
package directory

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"sync"
	"time"

	"invoicely/api/internal/metrics"
)

type cached struct {
	registered bool
	expires    time.Time
}

type Client struct {
	baseURL string
	http    *http.Client
	mu      sync.Mutex
	cache   map[string]cached
}

const cacheTTL = 10 * time.Minute

func New(baseURL string) *Client {
	return &Client{baseURL: baseURL, http: &http.Client{Timeout: 5 * time.Second}, cache: map[string]cached{}}
}

// IsRegistered reports whether a Peppol participant id can receive invoices.
func (c *Client) IsRegistered(ctx context.Context, participantID string) (bool, error) {
	// A file repeats the same few buyers on every line; look each one up once.
	c.mu.Lock()
	if e, ok := c.cache[participantID]; ok && time.Now().Before(e.expires) {
		c.mu.Unlock()
		return e.registered, nil
	}
	c.mu.Unlock()
	registered, err := c.lookup(ctx, participantID)
	if err == nil {
		c.mu.Lock()
		c.cache[participantID] = cached{registered, time.Now().Add(cacheTTL)}
		c.mu.Unlock()
	}
	return registered, err
}

func (c *Client) lookup(ctx context.Context, participantID string) (bool, error) {
	start := time.Now()
	result := "error"
	defer func() {
		metrics.ParticipantLookups.WithLabelValues(result).Observe(time.Since(start).Seconds())
	}()

	req, err := http.NewRequestWithContext(ctx, http.MethodGet,
		c.baseURL+"/v1/participants/"+url.PathEscape(participantID), nil)
	if err != nil {
		return false, err
	}
	resp, err := c.http.Do(req)
	if err != nil {
		return false, err
	}
	defer resp.Body.Close()
	_, _ = io.Copy(io.Discard, resp.Body)

	switch resp.StatusCode {
	case http.StatusOK:
		result = "registered"
		return true, nil
	case http.StatusNotFound:
		result = "not_registered"
		return false, nil
	default:
		return false, fmt.Errorf("participant lookup returned HTTP %d", resp.StatusCode)
	}
}
