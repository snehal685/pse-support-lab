package importer

import (
	"sync"
	"time"

	"invoicely/api/internal/pint"
	"invoicely/api/internal/sheet"
)

// Source is an uploaded file together with what was read from it.
type Source struct {
	Filename string
	Raw      []byte
	Workbook *sheet.Workbook
	Invoices []*pint.Invoice
	StoredAt time.Time
}

// SourceCache keeps uploaded files in memory so the batch page can show the
// source rows and offer the original file for download.
type SourceCache struct {
	mu      sync.RWMutex
	entries map[string]*Source
}

func NewSourceCache() *SourceCache {
	return &SourceCache{entries: map[string]*Source{}}
}

// maxSources bounds memory: each entry holds the raw file, the parsed workbook and
// every mapped invoice. Unbounded, this grew until the 128 MB container was OOM-killed.
const maxSources = 10

func (c *SourceCache) Put(importID string, s *Source) {
	s.StoredAt = time.Now()
	c.mu.Lock()
	c.entries[importID] = s
	for len(c.entries) > maxSources {
		var oldestID string
		var oldest time.Time
		for id, e := range c.entries {
			if oldestID == "" || e.StoredAt.Before(oldest) {
				oldestID, oldest = id, e.StoredAt
			}
		}
		delete(c.entries, oldestID)
	}
	c.mu.Unlock()
}

func (c *SourceCache) Get(importID string) (*Source, bool) {
	c.mu.RLock()
	defer c.mu.RUnlock()
	s, ok := c.entries[importID]
	return s, ok
}
